package httpmethods;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

public class httpCalls {
    public static String baseURL="https://petstore.swagger.io/v2";

    public Response  getCall(String param){

        return   given().baseUri(baseURL).
                contentType(ContentType.JSON).
                when().get(param)
                .then()
                //.assertThat().body(matchesJsonSchemaInClasspath("dummy.test.json"))
                .log()
                .ifValidationFails().assertThat()
                .statusCode(200)
                .extract().response();
    }
    public Response postCall(String body,String param){
        return given().baseUri(baseURL).
                contentType(ContentType.JSON).
                body(body).
                when().
                post(param).
                then().
                extract().
                response();

    }

    public Response deleteCall(String path, String str,Object value){

        return given().baseUri(baseURL)
                .pathParam(str,value)
                .when().delete(path+"{"+str+"}")
                .then()
                .extract().response();


    }

    public Response patchCall(String body,String path){
        return given().baseUri(baseURL).
                contentType(ContentType.JSON).
                body(body).
                when().
                patch(path).
                then().
                extract().response();

    }

    public Response optionsCall( String param){
        return given().baseUri(baseURL).
                when().
                options(param).
                then().log().all().
                extract().response();

    }

    public Response getRequestWithQueryParam(String path, String param ,String paramValue) {

        Response response = given().baseUri(baseURL)
                .contentType(ContentType.JSON)
                .queryParam(param, paramValue)
                .when()
                .get(path)
                .then()
                .extract().response();

        return response;

    }


    public Response  getDataByPathParameter(String path,String paramKey,Object paramValue){

        return   given()
                .baseUri(baseURL)
                .contentType(ContentType.JSON)
                .pathParam(paramKey,paramValue)
                .when()
                .get(path+"{"+paramKey+"}")
                .then()
                .extract()
                .response();
    }

}
