package stepDefinitions;

import httpmethods.httpCalls;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;

import static io.restassured.RestAssured.given;

public class SD1 extends httpCalls {

    private final String BASE_URL="https://petstore.swagger.io/v2/";
    public Response res;

    @Given("Get call to {string} with parameter {string}")
    public void getCallToWithParameter(String url, String status) {

        System.out.println(status);
        RequestSpecification httpRequest=given().baseUri(BASE_URL);
        System.out.println(httpRequest.log().all());
        res= httpRequest
                .contentType(ContentType.JSON)
                .queryParam("status",status)
                .when()
                .get(url);

        System.out.println("response: " + res.prettyPrint());
    }


    @Then("Response is {string}")
    public void responseIs(String statusCode) {


        int actualStatusCode=res.then()
                .extract().statusCode();
        Assert.assertEquals(statusCode,actualStatusCode+"");
    }

}
